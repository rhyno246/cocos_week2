System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Button, Component, director, instantiate, Label, Layout, Node, Prefab, _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _crd, ccclass, property, LevelCtrl;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Button = _cc.Button;
      Component = _cc.Component;
      director = _cc.director;
      instantiate = _cc.instantiate;
      Label = _cc.Label;
      Layout = _cc.Layout;
      Node = _cc.Node;
      Prefab = _cc.Prefab;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "1a13cxh0zBOobux3p7bga2N", "LevelCtrl", undefined);

      __checkObsolete__(['_decorator', 'Button', 'Component', 'director', 'instantiate', 'Label', 'Layout', 'Node', 'Prefab']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("LevelCtrl", LevelCtrl = (_dec = ccclass('LevelCtrl'), _dec2 = property({
        type: Button
      }), _dec3 = property({
        type: Button
      }), _dec4 = property({
        type: Prefab
      }), _dec5 = property({
        type: Node
      }), _dec(_class = (_class2 = class LevelCtrl extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "BtnNext", _descriptor, this);

          _initializerDefineProperty(this, "BtnPrev", _descriptor2, this);

          _initializerDefineProperty(this, "prefab", _descriptor3, this);

          _initializerDefineProperty(this, "layout", _descriptor4, this);

          this.pageIndex = 1;
          this.pageNumber = 3;
          this.maxLevel = 9;
          this.sizeButton = 60;
        }

        onLoad() {
          this.loadLevel();
          this.isShowNav();
        }

        loadLevel() {
          const levelStart = this.pageIndex * this.pageNumber - this.pageNumber + 1;
          const levelEnd = this.pageNumber * this.pageIndex;
          this.layout.removeAllChildren();
          const layout = this.layout.getComponent(Layout);

          for (let i = levelStart; i <= levelEnd; i++) {
            const button = instantiate(this.prefab);
            const label = button.getComponentInChildren(Label);
            this.layout.addChild(button);

            if (label) {
              label.string = `${i}`;
            }

            button.on(Button.EventType.CLICK, () => this.onSelectLevel(i));
          }

          if (layout) {
            layout.updateLayout();
          }
        }

        onSelectLevel(val) {
          localStorage.setItem('player_select_level', JSON.stringify({
            level: val
          }));
          director.loadScene('play');
        }

        onNextScreen() {
          this.pageIndex++;
          this.loadLevel();
          this.isShowNav();
        }

        onPrevScreen() {
          this.pageIndex--;
          this.loadLevel();
          this.isShowNav();
        }

        isShowNav() {
          this.BtnNext.node.active = false;
          this.BtnPrev.node.active = false;

          if (this.pageIndex > 1) {
            this.BtnPrev.node.active = true;
          }

          if (this.pageIndex < this.maxLevel / this.pageNumber) {
            this.BtnNext.node.active = true;
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "BtnNext", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "BtnPrev", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "prefab", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "layout", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=7dc28ce574f32d73c8510c0f2845249a6eaf3c69.js.map