System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Button, Component, director, Node, Sprite, UITransform, _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _crd, ccclass, property, Shopping;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Button = _cc.Button;
      Component = _cc.Component;
      director = _cc.director;
      Node = _cc.Node;
      Sprite = _cc.Sprite;
      UITransform = _cc.UITransform;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "e4659VoqoVMmroGGgEdf2uV", "ShoppingCtr", undefined);

      __checkObsolete__(['_decorator', 'Button', 'Component', 'director', 'Layout', 'Node', 'ScrollView', 'Sprite', 'UITransform']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("Shopping", Shopping = (_dec = ccclass('Shopping'), _dec2 = property({
        type: Button
      }), _dec3 = property({
        type: Node
      }), _dec4 = property({
        type: Node
      }), _dec(_class = (_class2 = class Shopping extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "backScreen", _descriptor, this);

          _initializerDefineProperty(this, "layoutBirds", _descriptor2, this);

          _initializerDefineProperty(this, "birds", _descriptor3, this);

          this.baseWidth = 130;
          this.baseHeight = 100;
          this.scaleX = 150;
          this.scaleY = 120;
        }

        backHome() {
          director.loadScene('scene');
        }

        onLoad() {
          var playerChoose = this.loadDataLocalStorage("player_choose"); // const scroll = this.layoutBirds.getComponent(ScrollView);
          // if(scroll){
          //     scroll.scrollToTop(5);
          //     scroll.node.on(Node.EventType.TOUCH_MOVE, this.onScrollMove, this);
          // }

          if (playerChoose) {
            this.initShopping(playerChoose);
          }
        }

        onSave(key, val) {
          var jsonData = JSON.stringify(val);
          localStorage.setItem(key, jsonData);
        }

        loadDataLocalStorage(key) {
          var jsonData = localStorage.getItem(key);

          if (jsonData) {
            return JSON.parse(jsonData);
          }

          return null;
        }

        initShopping(playerChoose) {
          this.birds.forEach(element => {
            var index = element.getSiblingIndex() + 1;
            console.log(playerChoose, index);

            if (playerChoose == index) {
              var elm = element.getComponent(UITransform);
              elm.setContentSize(this.scaleX, this.scaleY);
            }
          });
        }

        setSizebird(uiTransform) {
          this.birds.forEach(element => {
            var elm = element.getComponent(UITransform);
            elm.setContentSize(this.baseWidth, this.baseHeight);
          });

          if (uiTransform) {
            uiTransform.setContentSize(this.scaleX, this.scaleY);
          }
        }

        chooseBird(event) {
          var targetNode = event.target;
          var uiTransform = targetNode.getComponent(UITransform);
          var sprite = targetNode.getComponent(Sprite);

          if (sprite) {
            var index = sprite.node.getSiblingIndex();
            this.onSave("player_choose", index + 1);
          }

          if (uiTransform) {
            this.setSizebird(uiTransform);
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "backScreen", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "layoutBirds", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "birds", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=09960db772ec61f45802ad6389a211a704f290ab.js.map